//
//  Friend.swift
//  FriendBookPlus
//
//  Created by TangZekun on 11/12/15.
//  Copyright © 2015 TangZekun. All rights reserved.
//

import Foundation
import UIKit

class Friend
{
    var name = " "
    var birthday = " "
    var phoneNumber = " "
    var picture = UIImage()
}