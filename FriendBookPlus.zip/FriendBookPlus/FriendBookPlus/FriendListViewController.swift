//
//  ViewController.swift
//  FriendBookPlus
//
//  Created by TangZekun on 11/12/15.
//  Copyright © 2015 TangZekun. All rights reserved.
//

import UIKit

class FriendListViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    @IBOutlet weak var tableView: UITableView!
    
    var friends = [Friend]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        createFriends()
        self.tableView.dataSource = self
        self.tableView.delegate = self
    }
    
    func createFriends()
    {
        //"Neo", "Tang", "Wang", "Siyang"
        
        let neo = Friend ()
        neo.name = "Neo"
        neo.birthday = "June 25th"
        neo.phoneNumber = "54199999"
        neo.picture = UIImage(named: "Neo")!
        self.friends.append(neo)
        
        
        let tang = Friend ()
        tang.name = "Tang"
        tang.birthday = "July 11th"
        tang.phoneNumber = "541333"
        tang.picture = UIImage(named: "Tang")!
        self.friends.append(tang)
        
        let wang = Friend ()
        wang.name = "Wang"
        wang.birthday = "March 11th"
        wang.phoneNumber = "54144444"
        wang.picture = UIImage(named: "Wang")!
        self.friends.append(wang)
        
        let siyang = Friend ()
        siyang.name = "Siyang"
        siyang.birthday = "September 23th"
        siyang.phoneNumber = "5415555"
        siyang.picture = UIImage(named: "Siyang")!
        self.friends.append(siyang)
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.friends.count
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = UITableViewCell ()
        let friend = self.friends[indexPath.row]
        cell.textLabel?.text = friend.name
        return cell
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        tableView.deselectRowAtIndexPath(indexPath, animated: true)
        let friend = self.friends[indexPath.row]
        self.performSegueWithIdentifier("detailSegue", sender: friend)
    }

    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        let detailViewController = segue.destinationViewController as! FriendDetail
        detailViewController.friend  = sender as! Friend
     }

}

